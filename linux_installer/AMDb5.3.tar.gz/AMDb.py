# AMDb.py
# Path: AMDb.py

import sys
from PyQt5.QtCore import QTimer
from PyQt5.QtWidgets import QApplication
from config.config_handler import ConfigHandler
from config.logger import setup_logging, log_info, log_error, log_warning
from db.api_requests import set_api
from db.database_operations import set_db_path, database_init
from gui.main_window import MainApp
from gui.splash import Splash
from utils.path_utils import detect_os

# Define version number
VERSION_NUMBER = 5.3


def main():
    try:
        app = QApplication(sys.argv)
    except Exception as e:
        print(f"Failed to initialize QApplication: {e}")
        return

    try:
        # Show splash screen
        splash = Splash(version_number=VERSION_NUMBER)
        splash.show()
    except Exception as e:
        print(f"Failed to show splash screen: {e}")
        return

    try:
        # Detect the OS
        detect_os()
    except Exception as e:
        print(f"Failed to detect OS: {e}")
        return

    try:
        # Set up logging
        setup_logging()
        log_info("Starting AMDb")
    except Exception as e:
        print(f"Failed to set up logging: {e}")
        return

    try:
        # Initialize config handler
        config = ConfigHandler(version_number=VERSION_NUMBER)
    except Exception as e:
        log_error(f"Failed to initialize config handler: {e}")
        return

    try:
        # Initialize the database
        db_version = config.get_config_option("Database", "version")
        database_init(db_version, VERSION_NUMBER)
    except Exception as e:
        log_error(f"Failed to initialize the database: {e}")
        return

    try:
        # Set up the OMDb API
        set_server = config.get_config_option('API server', 'Set')
        api_key = config.get_config_option('API keys', set_server)
        api_url = config.get_config_option('API URLs', set_server)
        set_api(api_key, api_url)
    except Exception as e:
        log_error(f"Failed to set up the OMDb API: {e}")
        return

    try:
        # Close the splash screen after initializing the program with custom timer delay
        splash_time = int(config.get_config_option('Display', 'splash_time', default=5000))
        QTimer.singleShot(splash_time, splash.close)
    except Exception as e:
        log_error(f"Failed to set splash screen timer: {e}")
        return

    try:
        # Initialize and show the main window, passing config
        main_window = MainApp(config)
        main_window.show()
    except Exception as e:
        log_error(f"Failed to initialize and show main window: {e}")
        return

    try:
        sys.exit(app.exec_())
    except Exception as e:
        log_error(f"Application exit failed: {e}")


if __name__ == "__main__":
    main()
