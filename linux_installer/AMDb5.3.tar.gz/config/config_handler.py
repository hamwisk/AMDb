# config_handler.py
# Path: config/config_handler.py

import configparser
import os

from utils.path_utils import config_path


def make_config(config_file, version_number):
    from utils.encryption_utils import EncryptionUtil
    encryption = EncryptionUtil()
    api_key = encryption.encrypt('get your free key from "https://www.omdbapi.com/apikey.aspx"')
    config = configparser.ConfigParser()
    config['Database'] = {'version': str(version_number)}
    config['API server'] = {'options': 'omdb', 'set': 'omdb', 'request': 'get'}
    config['API keys'] = {'omdb': api_key}
    config['API URLs'] = {'omdb': 'http://www.omdbapi.com/'}
    config['Movie'] = {'extensions': 'mkv, mp4, avi, mov, flv, wmv, mpg, mpeg, m4v, webm'}
    config['Sort'] = {'method': '0', 'descending': 'True', 'buffer': '50'}
    config['Display'] = {'display_mode': 'list', 'window_width': '1234', 'window_height': '567', 'splash_time': '2255',
                         'delta_boost': '1'}

    with open(config_file, 'w') as file:
        config.write(file)


class ConfigHandler:
    def __init__(self, version_number):
        self.config = configparser.ConfigParser()
        self.config_file = config_path()
        self.version_number = version_number
        self.load_config()

    def load_config(self):
        if not os.path.isfile(self.config_file):
            make_config(self.config_file, self.version_number)
        self.config.read(self.config_file)

    def get_config_option(self, section, option, default=None):
        try:
            return self.config.get(section, option)
        except (configparser.NoOptionError, configparser.NoSectionError):
            return default if default is not None else None

    def save_config(self):
        with open(self.config_file, 'w') as config_file:
            self.config.write(config_file)

    def set_config_option(self, section, option, value):
        if not self.config.has_section(section):
            self.config.add_section(section)
        self.config.set(section, option, str(value))
        self.save_config()
