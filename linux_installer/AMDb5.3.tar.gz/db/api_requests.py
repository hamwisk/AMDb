# api_requests.py
# Path: db/api_requests.py

import requests

from config.logger import log_warning
from utils.encryption_utils import EncryptionUtil

api_key = None
api_url = None


def set_api(encrypted_key, url):
    encryption_util = EncryptionUtil()
    key = encryption_util.decrypt(encrypted_key)

    global api_key
    api_key = key
    global api_url
    api_url = url


def get_movie_data(movie):
    params = {'apikey': api_key, 't': movie['title'], 'y': movie['year']}
    response = requests.get(api_url, params=params)
    if response.status_code == 200:
        return response.json(), 200
    elif response.status_code == 401:
        log_warning(f"Failed to download {movie['path']} Please check your API settings in the preferences."
                    f" - Error: {response.status_code}")
    else:
        log_warning(f"Failed to download {movie['path']} - Error: {response.status_code}")
    return None, response.status_code


def search_movie_data(movie):
    params = {'apikey': api_key, 's': movie['title'], 'y': movie['year'], 'page': 1}
    response = requests.get(api_url, params=params)
    if response.status_code == 200:
        movie_data = response.json()
        return movie_data.get('Search', [])  # Return the list of movies
    else:
        # API request failed
        log_warning(f"Failed to download {movie['path']} - Error: {response.status_code}")
        return []


def get_tt_data(tt_code, long_plot):
    params = {'apikey': api_key, 'i': tt_code}
    if long_plot:
        params['plot'] = 'full'

    response = requests.get(api_url, params=params)
    if response.status_code == 200:
        return response.json()
    else:
        log_warning(f"Failed to download {tt_code} data - Error: {response.status_code}")
        return None


def get_movie_poster(poster_url):
    poster_response = requests.get(poster_url) if poster_url and poster_url != 'N/A' else None
    if poster_response and poster_response.status_code == 200:
        return poster_response
    else:
        return None
