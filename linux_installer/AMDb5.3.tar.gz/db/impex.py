# impex.py
# Path: db/impex.py

import configparser
import os
import shutil
import zipfile
from datetime import datetime

from PyQt5.QtWidgets import QFileDialog, QMessageBox

from config.logger import log_info, log_warning
from db.database_operations import update_poster_paths
from utils.path_utils import get_relative_path, assets_path


def export_db(self, version_number):
    log_info('Database Backup Initialized')

    current_db = get_relative_path(assets_path(), "movies.db")
    current_post = get_relative_path(assets_path(), "posters")
    backup_dir = f"backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    os.makedirs(backup_dir, exist_ok=True)

    try:
        shutil.copy(current_db, backup_dir)
        shutil.copytree(current_post, os.path.join(backup_dir, 'posters'))

        config = configparser.ConfigParser()
        config['Database'] = {'version': str(version_number)}
        config_file = os.path.join(backup_dir, 'config.ini')
        with open(config_file, 'w') as file:
            config.write(file)

        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog
        selected_filename = os.path.join(os.path.expanduser("~"),
                                         f"AMDb_{datetime.now().strftime('%Y%m%d_%H%M%S')}.backup")
        zip_filename, _ = QFileDialog.getSaveFileName(self, "Save Backup File", selected_filename,
                                                      "Backup Files;;All Files (*)", options=options)

        if zip_filename:
            with zipfile.ZipFile(zip_filename, 'w') as backup_zip:
                backup_zip.write(os.path.join(backup_dir, os.path.basename(current_db)), 'movies.db')
                backup_zip.write(config_file, 'config.ini')
                for root, dirs, files in os.walk(os.path.join(backup_dir, 'posters')):
                    for file in files:
                        file_path = os.path.join(root, file)
                        arcname = os.path.relpath(file_path, os.path.join(backup_dir, 'posters'))
                        backup_zip.write(file_path, os.path.join('posters', arcname))

            log_info(f'Database Backup Completed: {zip_filename}')
            QMessageBox.information(self, "Backup Completed",
                                    f"Database backup completed successfully. "
                                    f"Backup file saved to:\n{zip_filename}")
    except Exception as e:
        log_warning(f"Database backup failed: {e}")
        QMessageBox.warning(self, "Backup Failed", f"Database backup failed. Error: {e}")
    finally:
        shutil.rmtree(backup_dir, ignore_errors=True)


def get_major_version(version):
    return version.split('.')[0]


def import_db(self, config_handler):
    extraction_dir = ''
    log_info("Initializing database import")
    options = QFileDialog.Options()
    options |= QFileDialog.DontUseNativeDialog
    import_filename, _ = QFileDialog.getOpenFileName(self, "Select Backup File", os.path.expanduser("~"),
                                                     "Backup Files (*.backup);;All Files (*)", options=options)

    if import_filename:
        try:
            # Create a temporary directory for extraction
            extraction_dir = f"import_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            os.makedirs(extraction_dir, exist_ok=True)

            # Extract the contents of the backup file to the temporary directory
            with zipfile.ZipFile(import_filename, 'r') as backup_zip:
                backup_zip.extractall(extraction_dir)

            # Check if the user wants to continue without backing up
            response = QMessageBox.warning(self, "Warning",
                                           "Importing will overwrite your current database and posters.\n"
                                           "Do you want to back up your existing data before proceeding?",
                                           QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel,
                                           QMessageBox.Yes)

            if response == QMessageBox.Cancel:
                log_info("Database import canceled by user")
                return

            if response == QMessageBox.Yes:
                export_db(self, config_handler.get_config_option('Database', 'version'))

            # Import config file
            config = configparser.ConfigParser()
            config.read(os.path.join(extraction_dir, 'config.ini'))
            import_config = config['Database']['version']

            # Get major versions
            current_version = config_handler.get_config_option('Database', 'version')
            current_major_version = get_major_version(current_version)
            import_major_version = get_major_version(import_config)

            # Check the major version is the same
            if current_major_version == import_major_version:
                current_db = get_relative_path(assets_path(), "movies.db")
                imported_db = os.path.join(extraction_dir, 'movies.db')
                shutil.copy(imported_db, current_db)  # Import database file

                imported_posters = os.path.join(extraction_dir, 'posters')
                current_post = get_relative_path(assets_path(), "posters")
                update_poster_paths(current_post)
                shutil.rmtree(current_post, ignore_errors=True)
                shutil.copytree(imported_posters, current_post)  # Import posters folder

                log_info(f'Database Import Completed: {import_filename}')
                QMessageBox.information(self, "Import Successful", "Database import completed successfully.",
                                        QMessageBox.Ok)
            else:
                log_warning(f"Database import failed: Incompatible version ({import_config})")
                QMessageBox.critical(self, "Import Failed", f"Error during database import: "
                                                            f"Incompatible version ({import_config})", QMessageBox.Ok)
        except Exception as e:
            log_warning(f"Import Failed: Error during database import: {str(e)}")
            QMessageBox.critical(self, "Import Failed", f"Error during database import: {str(e)}", QMessageBox.Ok)
        finally:
            shutil.rmtree(extraction_dir, ignore_errors=True)
            return True
