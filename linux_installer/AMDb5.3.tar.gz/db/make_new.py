# make_new.py
# Path: db/make_new.py

import os
import shutil
import sqlite3

from PyQt5 import QtGui
from PyQt5.QtCore import pyqtSlot
from PyQt5.QtWidgets import QApplication, QPushButton, QLabel, QVBoxLayout, QDialog

from config.logger import log_info
from utils.path_utils import get_relative_path, assets_path


def drop_all_tables(database_path):
    conn = sqlite3.connect(database_path)
    cursor = conn.cursor()

    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name != 'sqlite_sequence';")
    tables = cursor.fetchall()

    for table in tables:
        table_name = table[0]
        drop_table_sql = f"DROP TABLE IF EXISTS {table_name};"
        cursor.execute(drop_table_sql)

    conn.commit()
    conn.close()


def create_tables(database_path):
    # SQL commands to create tables with constraints and optimizations
    sql_commands = [
        """CREATE TABLE movies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            imdb_id TEXT NOT NULL CHECK(length(imdb_id) <= 10),
            title TEXT NOT NULL,
            year INTEGER CHECK(year >= 1878),
            rated INTEGER,
            released DATE,
            runtime TEXT CHECK(length(runtime) <= 10),
            plot TEXT,
            long_plot TEXT,
            plot_toggle BOOLEAN,
            awards TEXT,
            imdb_rating INTEGER CHECK(imdb_rating >= 0 AND imdb_rating <= 100),
            rotten_tomatoes_rating INTEGER CHECK(rotten_tomatoes_rating >= 0 AND rotten_tomatoes_rating <= 100),
            metacritic_rating INTEGER CHECK(metacritic_rating >= 0 AND metacritic_rating <= 100),
            average_rating INTEGER CHECK(average_rating >= 0 AND average_rating <= 100),
            type TEXT CHECK(length(type) <= 10),
            production TEXT,
            poster_path TEXT,
            path TEXT,
            watched BOOLEAN,
            u_rate INTEGER CHECK(u_rate >= 0 AND u_rate <= 100),
            keyword_scrape_date DATE,
            last_verified DATE,
            has_parts BOOLEAN DEFAULT 0,
            FOREIGN KEY (rated) REFERENCES ratings(id)
        );""",
        """CREATE TABLE ratings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            rating TEXT NOT NULL
        );""",
        """INSERT INTO ratings (rating) VALUES ('G'), ('PG'), ('PG-13'), ('R'), ('NC-17'), ('NR/UR');""",
        """CREATE TABLE alias_titles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            movie_id INTEGER NOT NULL,
            alias_title TEXT NOT NULL,
            FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE
        );""",
        """CREATE INDEX idx_alias_titles_movie_id ON alias_titles (movie_id);""",
        """CREATE TABLE directors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL
        );""",
        """CREATE TABLE writers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL
        );""",
        """CREATE TABLE actors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL
        );""",
        """CREATE TABLE movie_directors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            movie_id INTEGER NOT NULL,
            director_id INTEGER NOT NULL,
            FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE,
            FOREIGN KEY (director_id) REFERENCES directors(id) ON DELETE CASCADE
        );""",
        """CREATE INDEX idx_movie_directors_movie_id ON movie_directors (movie_id);""",
        """CREATE INDEX idx_movie_directors_director_id ON movie_directors (director_id);""",
        """CREATE TABLE movie_writers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            movie_id INTEGER NOT NULL,
            writer_id INTEGER NOT NULL,
            FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE,
            FOREIGN KEY (writer_id) REFERENCES writers(id) ON DELETE CASCADE
        );""",
        """CREATE INDEX idx_movie_writers_movie_id ON movie_writers (movie_id);""",
        """CREATE INDEX idx_movie_writers_writer_id ON movie_writers (writer_id);""",
        """CREATE TABLE movie_actors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            movie_id INTEGER NOT NULL,
            actor_id INTEGER NOT NULL,
            FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE,
            FOREIGN KEY (actor_id) REFERENCES actors(id) ON DELETE CASCADE
        );""",
        """CREATE INDEX idx_movie_actors_movie_id ON movie_actors (movie_id);""",
        """CREATE INDEX idx_movie_actors_actor_id ON movie_actors (actor_id);""",
        """CREATE TABLE keywords (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            keyword TEXT NOT NULL
        );""",
        """CREATE TABLE movie_parts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            movie_id INTEGER NOT NULL,
            file_path VARCHAR(255) NOT NULL,
            FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE
        );""",
        """CREATE INDEX idx_movie_parts_movie_id ON movie_parts (movie_id);""",
        """CREATE TABLE movie_keywords (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            movie_id INTEGER NOT NULL,
            keyword_id INTEGER NOT NULL,
            UNIQUE (movie_id, keyword_id),
            FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE,
            FOREIGN KEY (keyword_id) REFERENCES keywords(id) ON DELETE CASCADE
        );""",
        """CREATE INDEX idx_movie_keywords_movie_id ON movie_keywords (movie_id);""",
        """CREATE INDEX idx_movie_keywords_keyword_id ON movie_keywords (keyword_id);""",
        """CREATE TABLE languages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            language TEXT NOT NULL
        );""",
        """CREATE TABLE movie_languages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            movie_id INTEGER NOT NULL,
            language_id INTEGER NOT NULL,
            FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE,
            FOREIGN KEY (language_id) REFERENCES languages(id) ON DELETE CASCADE
        );""",
        """CREATE INDEX idx_movie_languages_movie_id ON movie_languages (movie_id);""",
        """CREATE INDEX idx_movie_languages_language_id ON movie_languages (language_id);""",
        """CREATE TABLE countries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            country TEXT NOT NULL
        );""",
        """CREATE TABLE movie_countries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            movie_id INTEGER NOT NULL,
            country_id INTEGER NOT NULL,
            FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE,
            FOREIGN KEY (country_id) REFERENCES countries(id) ON DELETE CASCADE
        );""",
        """CREATE INDEX idx_movie_countries_movie_id ON movie_countries (movie_id);""",
        """CREATE INDEX idx_movie_countries_country_id ON movie_countries (country_id);""",
        """CREATE TABLE genres (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            genre TEXT NOT NULL
        );""",
        """CREATE TABLE movie_genres (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            movie_id INTEGER NOT NULL,
            genre_id INTEGER NOT NULL,
            FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE,
            FOREIGN KEY (genre_id) REFERENCES genres(id) ON DELETE CASCADE
        );""",
        """CREATE INDEX idx_movie_genres_movie_id ON movie_genres (movie_id);""",
        """CREATE INDEX idx_movie_genres_genre_id ON movie_genres (genre_id);"""
    ]

    conn = sqlite3.connect(database_path)
    cursor = conn.cursor()

    for command in sql_commands:
        cursor.execute(command)

    conn.commit()
    conn.close()


@pyqtSlot()
def reset_amdb():
    confirm_dialog = QDialog()
    confirm_dialog.setWindowTitle("Reset Database")
    confirm_dialog.setWindowIcon(QtGui.QIcon(QtGui.QPixmap(get_relative_path(assets_path(), 'amdb.ico'))))

    layout = QVBoxLayout()

    label = QLabel("This will reset all AMDb data.")
    continue_button = QPushButton("Continue")
    cancel_button = QPushButton("Cancel")
    layout.addWidget(label)
    layout.addWidget(continue_button)
    layout.addWidget(cancel_button)

    confirm_dialog.setLayout(layout)

    continue_button.clicked.connect(lambda: show_final_warning(confirm_dialog))
    cancel_button.clicked.connect(confirm_dialog.reject)

    confirm_dialog.exec_()
    return True


@pyqtSlot()
def show_final_warning(parent_dialog):
    # Close the initial dialog
    parent_dialog.accept()

    # Create the final warning dialog
    final_warning_dialog = QDialog()
    final_warning_dialog.setWindowTitle("Final Warning")
    final_warning_dialog.setWindowIcon(QtGui.QIcon(QtGui.QPixmap(get_relative_path(assets_path(), 'amdb.ico'))))

    layout = QVBoxLayout()

    label = QLabel("This action will drop all SQL tables and re-make them. Are you sure you want to proceed?\n"
                   "If you want to keep your movie data, export the database first.")
    proceed_button = QPushButton("Proceed")
    cancel_button = QPushButton("Cancel")
    layout.addWidget(label)
    layout.addWidget(QLabel("Please confirm your action:"))  # Offset the button positions
    layout.addWidget(proceed_button)
    layout.addWidget(cancel_button)

    final_warning_dialog.setLayout(layout)

    proceed_button.clicked.connect(lambda: perform_reset(final_warning_dialog))
    cancel_button.clicked.connect(final_warning_dialog.reject)

    # Position the final warning dialog offset from the first one
    screen_geometry = QApplication.desktop().screenGeometry()
    final_warning_dialog.move(screen_geometry.width() // 2 - 100, screen_geometry.height() // 2 - 100)

    final_warning_dialog.exec_()


@pyqtSlot()
def perform_reset(dialog):
    log_info("Resetting data...")
    database_path = get_relative_path(assets_path(), 'movies.db')
    posters_path = get_relative_path(assets_path(), 'posters')

    # Remove and recreate the posters folder
    if os.path.exists(posters_path):
        shutil.rmtree(posters_path)
    os.makedirs(posters_path)

    drop_all_tables(database_path)
    create_tables(database_path)
    log_info("SQL tables reset")

    dialog.accept()
