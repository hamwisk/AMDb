# movie_processing_thread.py
# Path: db/movie_processing_thread.py

import os
import shutil
import tempfile

from PIL import Image
from PyQt5.QtCore import QThread, pyqtSignal

from db.api_requests import get_movie_data, get_movie_poster, search_movie_data
from db.database_operations import movie_dupe_check, add_new_movie, add_series_parts, update_movies
from utils.path_utils import get_relative_path, assets_path


def resize_image(poster_path, target_width=300, target_height=None):
    with Image.open(poster_path) as image:
        output_path = os.path.splitext(poster_path)[0] + '.png'

        if target_height is None:
            if image.width != target_width:
                width_percent = target_width / float(image.size[0])
                height_size = int(float(image.size[1]) * float(width_percent))
                image = image.resize((target_width, height_size), Image.Resampling.LANCZOS)
                image.save(output_path)
        else:
            aspect_ratio = image.width / image.height
            if aspect_ratio > 1:  # Image is wider than tall
                new_width = target_width
                new_height = int(new_width / aspect_ratio)
            else:  # Image is taller than wide
                new_height = target_height
                new_width = int(new_height * aspect_ratio)

            new_img = Image.new("RGBA", (target_width, target_height), (0, 0, 0, 0))
            if new_width <= target_width and new_height <= target_height:
                x_offset = (target_width - new_width) // 2
                y_offset = (target_height - new_height) // 2
                new_img.paste(image, (x_offset, y_offset))
            else:
                image.thumbnail((target_width, target_height))
                x_offset = (target_width - image.width) // 2
                y_offset = (target_height - image.height) // 2
                new_img.paste(image, (x_offset, y_offset))
            new_img.save(output_path, "PNG")

    return output_path


def download_poster(poster_url, poster_path):
    def use_default_poster(path):
        shutil.copy(get_relative_path(assets_path(), 'media/default_poster.png'), path)

    if not poster_url or poster_url.lower() == 'n/a':
        use_default_poster(poster_path)
        return

    poster_response = get_movie_poster(poster_url)
    if poster_response:
        with open(poster_path, 'wb') as poster_file:
            poster_file.write(poster_response.content)
        resize_image(poster_path, target_width=300)
    else:
        use_default_poster(poster_path)


def download_temp_poster(poster_url):
    def use_default_temp_poster():
        return get_relative_path(assets_path(), 'media/default_poster.png')

    if not poster_url or poster_url.lower() == 'n/a':
        return use_default_temp_poster()

    poster_response = get_movie_poster(poster_url)
    if not poster_response:
        return use_default_temp_poster()

    filename = os.path.basename(poster_url)
    temp_path = os.path.join(tempfile.gettempdir(), filename)
    with open(temp_path, 'wb') as temp_file:
        temp_file.write(poster_response.content)
    poster_path = resize_image(temp_path, target_width=300, target_height=455)
    return poster_path


def process_meta_data(movie, movie_data):
    title = movie_data.get('Title', '')
    imdb_id = movie_data.get('imdbID', '')
    poster_path = get_relative_path(assets_path(), f"posters/{title}_{imdb_id}.png")
    download_poster(movie_data.get('Poster', ''), poster_path)

    has_parts = '|#| ' in movie['path']  # Check if there are multiple paths
    if has_parts:
        paths = sorted(movie['path'].split('|#|'))
        movie_id = ''
        parts = []
        is_first_part = True
        for part_path in paths:
            if is_first_part:
                movie_id = add_new_movie(movie_data, poster_path, part_path.strip())
                is_first_part = False
            else:
                parts.append(part_path)
        add_series_parts(movie_id, parts)
        movie_ids = [movie_id]
        details = {"has_parts": 1}
        update_movies(movie_ids, details)
    else:
        movie_id = add_new_movie(movie_data, poster_path, movie['path'])
    return movie_id


class MovieProcessingThread(QThread):
    emit_progress_signal = pyqtSignal(int)
    emit_search_results_signal = pyqtSignal(dict)
    emit_complete_signal = pyqtSignal()
    emit_invalid_api_key_signal = pyqtSignal()

    def __init__(self, movies, r_type, parent=None):
        super(MovieProcessingThread, self).__init__(parent)
        self.movies = movies
        self.r_type = r_type
        self.progress = 0

    def run(self):
        total_movies = len(self.movies)  # Total number of movies to process
        to_search = []
        if self.r_type == 'search':
            to_search = self.movies
            self.movies = []

        # First loop: Process each movie in self.movies
        for index, movie in enumerate(self.movies):
            movie_data, status = get_movie_data(movie)  # Get movie metadata from the OMDb API
            if status == 200 and movie_data.get('Response', '') == 'True':
                details = {'title': movie_data['Title'], 'year': movie_data['Year']}
                duplicate = movie_dupe_check(details)
                if not duplicate:
                    process_meta_data(movie, movie_data)
                    self.progress = int(100 * (index + 1) / total_movies)
                    self.emit_progress_signal.emit(self.progress)
                if duplicate:
                    to_search.append(movie)
            elif status == 401:
                self.emit_invalid_api_key_signal.emit()
                return
            elif movie_data.get('Response', '') == 'False':
                to_search.append(movie)

        # Second loop: Process each movie in to_search
        for index, movie in enumerate(to_search):
            movie_options = []  # List to store movie options for the current movie
            movie_data = search_movie_data(movie)
            for movie_result in movie_data:
                if movie_result.get('Type') in ['movie', 'series', 'episode']:
                    title = movie_result.get('Title')
                    year = movie_result.get('Year')
                    imdb_id = movie_result.get('imdbID')
                    tmp_path = download_temp_poster(movie_result.get('Poster'))
                    movie_option = {
                        'index': index,
                        'imdb_id': imdb_id,
                        'title': title,
                        'year': year,
                        'poster': tmp_path,
                        'path': movie['path']
                    }
                    movie_options.append(movie_option)  # Add movie option to list

            # Emit options signal for the current movie
            self.emit_search_results_signal.emit(
                {'index': index, 'options': movie_options, 'path': movie['path']})

            # Calculate progress percentage for the second loop
            self.progress = int(100 * (index + 1 + total_movies) / (total_movies + len(to_search)))
            self.emit_progress_signal.emit(self.progress)

        # Processing is complete
        self.emit_complete_signal.emit()
