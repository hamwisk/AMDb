# fix_dialog.py
# Path: gui/fix_dialog.py

import os
from datetime import datetime

from PyQt5 import QtGui
from PyQt5.QtCore import pyqtSlot, pyqtSignal
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QDialog, QVBoxLayout, QLabel, QLineEdit, QPushButton, QFileDialog, QMessageBox

from config.logger import log_info, log_warning
from db.database_operations import get_full_movie_data, update_movies, u_delete
from utils.path_utils import get_relative_path, assets_path


class FixPathDialog(QDialog):
    finished = pyqtSignal()

    def __init__(self, movie_id, parent=None):
        super().__init__(parent)
        self.submit_button = None
        self.title = None
        self.broken_path = None
        self.line_edit = None
        self.movie_id = movie_id
        self.database_path = get_relative_path(assets_path(), 'movies.db')
        self.init_ui()

    def init_ui(self):
        movie_data = get_full_movie_data(self.movie_id)

        self.setWindowTitle(f"Correct Movie Path for {movie_data[1]}")
        self.setWindowIcon(QtGui.QIcon(get_relative_path(assets_path(), 'amdb.ico')))

        layout = QVBoxLayout()

        # Create UI elements
        self.title = movie_data[1]
        title_label = QLabel(movie_data[1])
        year_label = QLabel(str(movie_data[2]))
        poster_label = QLabel()
        poster_label.setPixmap(QPixmap(movie_data[5]))
        self.broken_path = movie_data[22]
        self.line_edit = QLineEdit(self.broken_path)
        browse_button = QPushButton("Browse")
        self.submit_button = QPushButton("Skip")
        delete_button = QPushButton("Delete")

        # Add UI elements to the layout
        layout.addWidget(title_label)
        layout.addWidget(year_label)
        layout.addWidget(poster_label)
        layout.addWidget(self.line_edit)
        layout.addWidget(browse_button)
        layout.addWidget(self.submit_button)
        layout.addWidget(delete_button)

        # Connect signals to slots
        browse_button.clicked.connect(self.select_path)
        self.submit_button.clicked.connect(self.submit_paths)
        delete_button.clicked.connect(self.delete_movie)
        self.line_edit.textChanged.connect(self.skip_continue)

        self.setLayout(layout)

    @pyqtSlot()
    def skip_continue(self):
        if self.line_edit.text() == self.broken_path:
            self.submit_button.setText("Skip")
        else:
            self.submit_button.setText("Submit")

    @pyqtSlot()
    def select_path(self):
        open_folder = os.path.expanduser("~")
        new_path, _ = QFileDialog.getOpenFileName(
            self, 'Select Movie File', open_folder, 'Video Files (*.mp4 *.mkv *.avi);;All Files (*)'
        )
        if new_path:
            self.line_edit.setText(new_path)

    @pyqtSlot()
    def submit_paths(self):
        new_path = self.line_edit.text()
        if new_path != self.broken_path:
            movie_ids = [self.movie_id]
            details = {"path": new_path,
                       "last_verified": datetime.now().strftime('%Y-%m-%d')}
            update_movies(movie_ids, details)

            log_info(f"Path updated for {self.title} to {new_path}")
        else:
            log_warning(f"Movie with broken path update skipped: {self.title}")
        self.finished.emit()  # Emit finished signal
        super(FixPathDialog, self).accept()

    def delete_movie(self):
        u_delete(self.movie_id, self.title)
        QMessageBox.information(self, 'Movie Deleted', f"The movie '{self.title}' was deleted successfully.")
        self.finished.emit()
        self.close()
