# preferences_dialog.py
# Path: gui/preferences_dialog.py

from PyQt5 import QtGui
from PyQt5.QtWidgets import QDialog, QMessageBox

from db.api_requests import set_api
from gui.ui_preferences import Ui_Dialog
from utils.encryption_utils import EncryptionUtil
from utils.path_utils import get_relative_path, assets_path


class PreferencesDialog(QDialog, Ui_Dialog):
    def __init__(self, config):
        super().__init__()
        self.setupUi(self)

        # Store the ConfigHandler and encryption_utils instance
        self.config_handler = config
        self.encryption_util = EncryptionUtil()

        # Initialize UI and load preferences
        self.init_ui()
        self.setWindowIcon(QtGui.QIcon(get_relative_path(assets_path(), 'amdb.ico')))
        self.setWindowTitle("AMDb Preferences")
        self.load_preferences()

        # Connect signals and slots
        self.connect_signals()

    def init_ui(self):
        """Initialize UI components and additional setup."""
        # Populate API server dropdown
        api_ops = sorted(self.config_handler.get_config_option('API server', 'options').split(', '))
        for api in api_ops:
            self.API_server.addItem(api)

    def load_preferences(self):
        """Load existing preferences into the UI."""
        # Load API settings
        api_selected = self.config_handler.get_config_option('API server', 'set')
        self.lineEdit_host.setText(self.config_handler.get_config_option('API URLs', api_selected))
        encrypted_api = self.config_handler.get_config_option('API keys', api_selected)
        self.lineEdit_key.setText(self.encryption_util.decrypt(encrypted_api))

        # Load request type preferences
        request_type = self.config_handler.get_config_option('API server', 'r_type', default='get')
        if request_type == 'get':
            self.r_type_s.setChecked(True)
        else:
            self.r_type_a.setChecked(True)

    def connect_signals(self):
        """Connect UI components to their corresponding slots."""
        self.toolBox.currentChanged.connect(self.update_stacked_widget)
        self.buttonBox.accepted.connect(self.apply_preferences)
        self.API_server.currentIndexChanged.connect(self.on_api_server_changed)

    def apply_preferences(self):
        """Apply and save the preferences."""
        # Save API settings
        api_selected = self.API_server.currentText()
        self.config_handler.set_config_option('API server', 'set', api_selected)
        self.config_handler.set_config_option('API URLs', api_selected, self.lineEdit_host.text())
        plain_text_key = self.lineEdit_key.text()
        key = self.encryption_util.encrypt(plain_text_key)
        self.config_handler.set_config_option('API keys', api_selected, key)
        set_api(key, self.lineEdit_host.text())

        # Save request type preferences
        request_type = 'get' if self.r_type_s.isChecked() else 'search'
        self.config_handler.set_config_option('API server', 'request', request_type)

        # Show a message box indicating that preferences have been applied
        QMessageBox.information(self, 'Preferences Applied', 'Preferences have been applied successfully.')

    def update_stacked_widget(self, index):
        """Update the current page in the stacked widget when the toolbox tab is changed."""
        self.stackedWidget.setCurrentIndex(index)

    def on_api_server_changed(self, index):
        """Handle API server selection change."""
        api_selected = self.API_server.itemText(index)
        self.lineEdit_host.setText(self.config_handler.get_config_option('API url', api_selected))
        encrypted_api = self.config_handler.get_config_option('API keys', api_selected)
        key = self.encryption_util.decrypt(encrypted_api)
        self.lineEdit_key.setText(key)
