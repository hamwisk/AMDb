# __init__.py
# Path: styles/__init__.py

selected_style = """
    QWidget {
        background-color: lightblue;
        color: black;
    }
"""

unselected_style = """
    QWidget {
        background-color: white;
        color: black;
    }
"""
