# search_dialog.py
# Path gui/search_dialog.py

from PyQt5 import QtGui, QtCore
from PyQt5.QtWidgets import QDialog, QListWidgetItem

from db.api_requests import get_tt_data
from db.movie_processing_thread import download_temp_poster
from gui.ui_search_dialog import Ui_Dialog
from utils.path_utils import get_relative_path, assets_path


class MovieSelectionDialog(QDialog, Ui_Dialog):
    def __init__(self, movie_options, parent=None):
        super().__init__(parent)
        self.index = movie_options['index']
        self.movie_options = movie_options['options']
        self.path = movie_options['path']

        self.setupUi(self)
        self.setWindowTitle("Select Movie")
        self.setWindowIcon(QtGui.QIcon(get_relative_path(assets_path(), 'amdb.ico')))

        self.pushButton.clicked.connect(self.add_movie_option)
        self.buttonBox.accepted.connect(self.accept)
        self.buttonBox.rejected.connect(self.reject)
        self.movie_list_widget.itemSelectionChanged.connect(self.update_poster_preview)

        self.populate_list()
        self.label.setText(f"Select the correct movie:\n{self.path}")

    def populate_list(self):
        # Populate the list widget with movie titles
        self.movie_list_widget.clear()
        for movie in self.movie_options:
            item = QListWidgetItem(f"{movie.get('title')} ({movie.get('year')})")
            item.setData(QtCore.Qt.UserRole, movie)
            self.movie_list_widget.addItem(item)

    def update_poster_preview(self):
        current_item = self.movie_list_widget.currentItem()
        if current_item:
            movie = current_item.data(QtCore.Qt.UserRole)
            poster_path = movie.get('poster')
            self.set_poster(poster_path)

    def set_poster(self, poster_path):
        self.poster_preview.setPixmap(QtGui.QPixmap(poster_path))

    def selected_movie(self):
        current_item = self.movie_list_widget.currentItem()
        if current_item:
            return current_item.data(QtCore.Qt.UserRole)
        return None

    def add_movie_option(self):
        movie_data = get_tt_data(self.tt_edit.text(), long_plot=0)
        if movie_data and movie_data.get('Response') == 'True':
            index = len(self.movie_options) + 1
            title = movie_data.get('Title')
            year = movie_data.get('Year')
            imdb_id = movie_data.get('imdbID')
            tmp_path = download_temp_poster(movie_data.get('Poster'))
            movie = {
                'index': index,
                'imdb_id': imdb_id,
                'title': title,
                'year': year,
                'poster': tmp_path,
                'path': self.path
            }
            self.movie_options.append(movie)  # Add movie option to list
            self.populate_list()
