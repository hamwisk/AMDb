# splash.py
# Path: gui/splash.py

from PyQt5 import QtGui, QtCore
from PyQt5.QtWidgets import QMainWindow, QApplication

from gui.ui_splash import Ui_SplashScreen
from utils.path_utils import get_relative_path, assets_path


class Splash(QMainWindow):
    def __init__(self, version_number=None, parent=None):
        super().__init__(parent)
        self.ui = Ui_SplashScreen()
        self.ui.setupUi(self)
        self.setWindowFlags(self.windowFlags() | QtCore.Qt.WindowStaysOnTopHint)
        self.setWindowIcon(QtGui.QIcon(get_relative_path(assets_path(), 'amdb.ico')))
        self.setWindowTitle("Andy's Movie Database")

        self.ui.splash_image.setPixmap(QtGui.QPixmap(get_relative_path(assets_path(), 'media/splash.png')))
        self.ui.version_number.setText(str(version_number))

        self.center()

    def center(self):
        # Center the window on the screen
        frameGm = self.frameGeometry()
        screen = QApplication.desktop().screenNumber(QApplication.desktop().cursor().pos())
        centerPoint = QApplication.desktop().screenGeometry(screen).center()
        frameGm.moveCenter(centerPoint)
        self.move(frameGm.topLeft())
