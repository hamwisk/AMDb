# key_gen.py
# Path: utils/key_gen.py

import sys

from cryptography.fernet import Fernet


def generate_key():
    return Fernet.generate_key().decode()  # Generate a new key


def replace_placeholder(file_path, placeholder, new_key):
    """Replace the placeholder in the file with the new key."""
    with open(file_path, 'r') as file:
        filedata = file.read()

    # Replace the target string
    filedata = filedata.replace(placeholder, new_key)

    # Write the file out again
    with open(file_path, 'w') as file:
        file.write(filedata)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python generate_key.py <path_to_encryption_utils.py>")
        sys.exit(1)

    filePath = sys.argv[1]
    newKey = generate_key()
    replace_placeholder(filePath, "PLACEHOLDER_KEY", newKey)
    print(f"New encryption key generated and injected: {newKey}")
