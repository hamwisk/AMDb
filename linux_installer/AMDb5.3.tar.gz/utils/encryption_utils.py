# encryption_util.py
# Path: utils/encryption_utils.py

from cryptography.fernet import Fernet


ENCRYPTION_KEY = "PLACEHOLDER_KEY="


class EncryptionUtil:
    def __init__(self, key=ENCRYPTION_KEY):
        self.key = key.encode()
        self.cipher = Fernet(self.key)

    def encrypt(self, plaintext):
        if isinstance(plaintext, str):
            plaintext = plaintext.encode()  # Convert to bytes
        encrypted_text = self.cipher.encrypt(plaintext)
        return encrypted_text.decode()  # Return as string

    def decrypt(self, encrypted_text):
        encrypted_text = encrypted_text.encode()  # Convert to bytes
        decrypted_text = self.cipher.decrypt(encrypted_text)
        return decrypted_text.decode()  # Return as string
