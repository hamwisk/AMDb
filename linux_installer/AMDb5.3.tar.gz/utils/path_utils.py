# path_utils.py
# Path: utils/path_utils.py

import os
import platform

# Global variable to store the host operating system
host_os = None


def detect_os():
    global host_os
    if host_os is None:
        host_os = platform.system()
    return host_os


def get_os_based_path():
    os_name = detect_os()
    if os_name == 'Windows':
        return {
            'config': os.path.join(os.getenv('LOCALAPPDATA'), 'AMDb', 'config.ini'),
            'logs': os.path.join(os.getenv('LOCALAPPDATA'), 'AMDb', 'logs'),
            'assets': os.path.join(os.getenv('LOCALAPPDATA'), 'AMDb', 'assets')
        }
    elif os_name == 'Darwin':
        return {
            'config': os.path.join(os.getenv('HOME'), 'Library', 'Application Support', 'AMDb', 'config.ini'),
            'logs': os.path.join(os.getenv('HOME'), 'Library', 'Logs', 'AMDb'),
            'assets': os.path.join(os.getenv('HOME'), 'Library', 'Application Support', 'AMDb', 'assets')
        }
    else:  # Assuming Linux
        return {
            'config': os.path.join(os.getenv('HOME'), '.config', 'amdb', 'config.ini'),
            'logs': os.path.join(os.getenv('HOME'), '.local', 'share', 'amdb', 'logs'),
            'assets': os.path.join(os.getenv('HOME'), '.local', 'share', 'amdb', 'assets')
        }


def config_path():
    return get_os_based_path()['config']


def logs_path():
    return get_os_based_path()['logs']


def assets_path():
    return get_os_based_path()['assets']


def get_relative_path(base_path, relative_path):
    return os.path.join(base_path, relative_path)
